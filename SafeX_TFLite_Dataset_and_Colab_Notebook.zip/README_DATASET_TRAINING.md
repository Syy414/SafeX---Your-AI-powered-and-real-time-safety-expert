# SafeX — Dataset + TFLite Training

Open `SafeX_TFLite_Triage_Training.ipynb` in Google Colab and run from top to bottom.

Outputs:
- `safex_triage_multiclass/model.tflite`  (BENIGN + 6 scam categories)
- `safex_triage_binary/model.tflite`      (SCAM vs BENIGN)

These are starter triage models (not final security classifiers).
